class Net(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  fc1 : __torch__.torch.nn.modules.linear.Linear
  out : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  def forward(self: __torch__.policies.DQN_policy.Net,
    x: Tensor) -> Tensor:
    x0 = (self.fc1).forward(x, )
    x1 = __torch__.torch.nn.functional.relu(x0, False, )
    return (self.out).forward(x1, )
  def select_action(self: __torch__.policies.DQN_policy.Net,
    state: List[float],
    deterministic: bool=False) -> List[int]:
    state0 = torch.tensor(state, dtype=None, device=None, requires_grad=False)
    action = (self).forward(state0, )
    action0 = torch.item(torch.argmax(action, None, False))
    return [int(action0)]
